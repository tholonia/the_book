   austria   energy   earth 
volt  volts  volts VOLTS VOLTAGE voltmeter Bohr 
